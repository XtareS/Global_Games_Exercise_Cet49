﻿
namespace Global_Games_Exercise_Cet49.Data.Entities
{
    public class AvatUser
    {
        public int Id { get; set; }




    }
}
